# Excel steps

1. Open `../Data/ecommerce_sales.csv` in Excel.
2. Add a new column named `Sales`: `=G2*H2` (assuming Quantity is column G and UnitPrice is H).
3. Add `Cost`: `=G2*I2`.
4. Add `Profit`: `=J2-K2` (if Sales is J and Cost is K; adjust based on your sheet).
5. Select the data and choose Insert > PivotTable.
6. Create PivotTables:
   - Rows: OrderDate (group by month); Values: Sum of Sales.
   - Rows: Region; Values: Sum of Sales.
   - Rows: Category; Values: Sum of Sales.
   - Rows: Customer; Values: Sum of Sales.
7. Add charts from the PivotTables.
