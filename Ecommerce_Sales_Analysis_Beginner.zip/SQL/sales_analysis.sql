-- Beginner E-Commerce Sales Analysis
-- Table name assumed: ecommerce_sales
-- Import Data/ecommerce_sales.csv into your SQL tool first.

-- 1. View all rows
SELECT * FROM ecommerce_sales;

-- 2. Total sales and profit
SELECT
    SUM(Quantity * UnitPrice) AS total_sales,
    SUM(Quantity * (UnitPrice - UnitCost)) AS total_profit
FROM ecommerce_sales;

-- 3. Monthly sales (SQLite syntax)
SELECT
    strftime('%Y-%m', OrderDate) AS sales_month,
    SUM(Quantity * UnitPrice) AS monthly_sales
FROM ecommerce_sales
GROUP BY strftime('%Y-%m', OrderDate)
ORDER BY sales_month;

-- 4. Sales by region
SELECT
    Region,
    SUM(Quantity * UnitPrice) AS total_sales
FROM ecommerce_sales
GROUP BY Region
ORDER BY total_sales DESC;

-- 5. Top 5 customers
SELECT
    Customer,
    SUM(Quantity * UnitPrice) AS total_sales
FROM ecommerce_sales
GROUP BY Customer
ORDER BY total_sales DESC
LIMIT 5;

-- 6. Category-wise sales
SELECT
    Category,
    SUM(Quantity * UnitPrice) AS total_sales
FROM ecommerce_sales
GROUP BY Category
ORDER BY total_sales DESC;

-- 7. Best-selling products by quantity
SELECT
    Product,
    SUM(Quantity) AS units_sold
FROM ecommerce_sales
GROUP BY Product
ORDER BY units_sold DESC;
