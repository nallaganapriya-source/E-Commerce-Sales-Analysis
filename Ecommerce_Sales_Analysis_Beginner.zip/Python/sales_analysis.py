"""
Beginner E-Commerce Sales Analysis
Run: pip install pandas matplotlib
     python sales_analysis.py
"""
import pandas as pd
import matplotlib.pyplot as plt

# 1. Load data
df = pd.read_csv("../Data/ecommerce_sales.csv")

# 2. Basic data cleaning
df["OrderDate"] = pd.to_datetime(df["OrderDate"], errors="coerce")
df = df.dropna()
df = df.drop_duplicates()

# 3. Create useful calculated columns
df["Sales"] = df["Quantity"] * df["UnitPrice"]
df["Cost"] = df["Quantity"] * df["UnitCost"]
df["Profit"] = df["Sales"] - df["Cost"]
df["Month"] = df["OrderDate"].dt.to_period("M").astype(str)

# 4. Display key business numbers
print("TOTAL SALES:", df["Sales"].sum())
print("TOTAL PROFIT:", df["Profit"].sum())
print("TOTAL ORDERS:", df["OrderID"].nunique())

# 5. Monthly sales
monthly_sales = df.groupby("Month")["Sales"].sum().sort_index()
print("\nMONTHLY SALES\n", monthly_sales)

# 6. Sales by region
region_sales = df.groupby("Region")["Sales"].sum().sort_values(ascending=False)
print("\nSALES BY REGION\n", region_sales)

# 7. Top 5 customers
top_customers = df.groupby("Customer")["Sales"].sum().sort_values(ascending=False).head(5)
print("\nTOP CUSTOMERS\n", top_customers)

# 8. Category sales
category_sales = df.groupby("Category")["Sales"].sum().sort_values(ascending=False)
print("\nSALES BY CATEGORY\n", category_sales)

# 9. Save cleaned data for Excel / Power BI
df.to_csv("../Data/cleaned_ecommerce_sales.csv", index=False)

# 10. Save charts
monthly_sales.plot(kind="bar", title="Monthly Sales")
plt.xlabel("Month")
plt.ylabel("Sales")
plt.tight_layout()
plt.savefig("monthly_sales.png")
plt.close()

region_sales.plot(kind="bar", title="Sales by Region")
plt.xlabel("Region")
plt.ylabel("Sales")
plt.tight_layout()
plt.savefig("sales_by_region.png")
plt.close()

print("\nDone! Cleaned CSV and charts have been created.")
