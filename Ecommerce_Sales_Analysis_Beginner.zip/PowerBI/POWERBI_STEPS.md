# Power BI dashboard steps

1. Open Power BI Desktop.
2. Select Get Data > Text/CSV and import `Data/cleaned_ecommerce_sales.csv`.
3. Check that OrderDate is Date and numeric columns are Decimal Number / Whole Number.
4. Create measures:
   - Total Sales = SUM(cleaned_ecommerce_sales[Sales])
   - Total Profit = SUM(cleaned_ecommerce_sales[Profit])
   - Total Orders = DISTINCTCOUNT(cleaned_ecommerce_sales[OrderID])
5. Add Card visuals for Total Sales, Total Profit, Total Orders.
6. Add a Line chart: Axis = Month, Values = Total Sales.
7. Add a Bar chart: Axis = Region, Values = Total Sales.
8. Add a Column chart: Axis = Category, Values = Total Sales.
9. Add a Bar chart: Axis = Customer, Values = Total Sales.
10. Add slicers for Region and Category.
11. Save as `ecommerce_sales_dashboard.pbix` in this folder.
