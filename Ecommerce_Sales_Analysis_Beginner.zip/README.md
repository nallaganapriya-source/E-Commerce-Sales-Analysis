# Beginner E-Commerce Sales Analysis

## Project goal
Analyze a small sample e-commerce dataset and answer basic business questions:
- How much sales and profit did the store make?
- Which month had the highest sales?
- Which region and category performed best?
- Who are the top customers?

## Tools
- Python (Pandas, Matplotlib)
- SQL
- Excel
- Power BI

## Files
- `Data/ecommerce_sales.csv` - sample raw dataset
- `Python/sales_analysis.py` - beginner Python analysis
- `SQL/sales_analysis.sql` - SQL practice queries
- `Excel/EXCEL_STEPS.md` - Excel instructions
- `PowerBI/POWERBI_STEPS.md` - Power BI dashboard instructions

## Run Python
1. Install Python.
2. Open a terminal inside the `Python` folder.
3. Install packages: `pip install pandas matplotlib`
4. Run: `python sales_analysis.py`

The script creates `Data/cleaned_ecommerce_sales.csv` and two chart images.
If running from a different folder, update the CSV path in the script.

## Excel
Open `Data/ecommerce_sales.csv`. Add columns:
- Sales = Quantity * UnitPrice
- Cost = Quantity * UnitCost
- Profit = Sales - Cost
Then create PivotTables by Month, Region, Category, and Customer.

## SQL
Import `Data/ecommerce_sales.csv` into a table named `ecommerce_sales`.
Run the queries in `SQL/sales_analysis.sql`.
The monthly query uses SQLite date syntax; other queries use common SQL syntax.

## Power BI
Import `Data/cleaned_ecommerce_sales.csv` (or the original CSV).
Create cards for Total Sales, Total Profit, and Total Orders.
Create charts for Monthly Sales, Sales by Region, Sales by Category, and Top Customers.
Add slicers for Region and Category.

## Important
This is a small practice dataset created for learning. The findings are examples, not real company results.
Customize the project, understand every query, and add your own observations before publishing it to GitHub.
